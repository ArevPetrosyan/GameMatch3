﻿using System.Windows.Controls;
using System.Windows.Media;

namespace Match3.Classes
{
    public class Cell
    {
        private int _top;
        private int _left;
        private bool _isBonus;
        private bool _isBomb;

        public PieceType PieceType { get; set; }
        public int Top
        {
            get => _top;
            set => _top = value;
        }

        public bool IsBomb
        {
            get => _isBomb;
            set
            {
                _isBomb = value;
                if (_isBomb)
                {
                    this.Image.Source = UIImages.Images[(int)PieceType + 10];
                }
            }
        }

        public bool IsBonus
        {
            get => _isBonus;
            set
            {
                _isBonus = value;
                if(_isBonus)
                {
                    this.Image.Source = UIImages.Images[(int)PieceType + 5];
                }                
            }
        }


        public int Left
        {
            get => _left;
            set => _left = value;
        }

        public Image Image { get; set; }

        public bool Selected { get; set; }
               
        public Cell(int top, int left, PieceType pieceType, ImageSource imageSource)
        {
            Top = top;
            Left = left;
            PieceType = pieceType;
            Image = new Image
            {
                Source = imageSource,
                Tag = this
            };
        }

        public void SwapCoordinates(ref Cell other)
        {
            Utility.Swap(ref _top, ref other._top);
            Utility.Swap(ref _left, ref other._left);
        }
    }
}
