﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows;
using JetBrains.Annotations;

namespace Match3.Classes
{
    public sealed class Game : INotifyPropertyChanged
    {
        public int Points
        {
            get => _points;
            set
            {
                _points = value;
                OnPropertyChanged();
            }
        }

        public int Countdown
        {
            get => _countdown;
            set
            {
                _countdown = value;
                OnPropertyChanged();
            }
        }

        public Game(Action<Cell> setCell, Action<Cell> removeCell, Action<Cell> dropAnimation)
        {
            FillBoard(setCell);
            DeleteAndDropCells(dropAnimation, setCell, removeCell);
            _gameTimer = new DispatcherTimer(new TimeSpan(0, 0, 1), DispatcherPriority.Normal,
                delegate
                {
                    Countdown -= 1;
                    if (Countdown == 0)
                    {
                        PageNavigation.Switch(new GameOver(Points));
                    }
                }, Application.Current.Dispatcher);
        }

        public void RemoveMatches(Action<Cell> deleteAnimation)
        {
            _lastMatches = CheckMatches();
            Points += _lastMatches.Count;
            foreach (var match in _lastMatches)
            {
                deleteAnimation(match);
            }
        }

        private readonly Cell[,] _board = new Cell[16, 8];

        public void FillBoard(Action<Cell> setCellCallback)
        {
            var r = new Random();
            for (var i = 0; i < 8; i++)
            {
                for (var j = 0; j < 8; j++)
                {
                    if (_board[i, j] != null) continue;

                    var num = r.Next(5);
                    _board[i, j] = new Cell(i - 8, j, (PieceType)num, UIImages.Images[num]);
                    setCellCallback(_board[i, j]);
                }
            }
        }

        private List<Cell> _lastMatches = new List<Cell>();
        private int _points;
        private int _countdown = 60;
        private readonly DispatcherTimer _gameTimer;
        private int _topPoint;
        private int _leftPoint;

        public void TrySwapCells(Cell first, Cell second, Action<Cell, Cell> successAnimCallback, Action<Cell, Cell> failAnimCallback)
        {
            if (Math.Abs(first.Top - second.Top) + Math.Abs(first.Left - second.Left) > 1)
                return;

            _topPoint = first.Top;
            _leftPoint = first.Left;
            Utility.Swap(ref _board[first.Top + 8, first.Left], ref _board[second.Top + 8, second.Left]);
            _lastMatches = CheckMatches();
            if (_lastMatches.Count > 0)
            {
                first.SwapCoordinates(ref second);
                successAnimCallback(first, second);
            }
            else
            {
                Utility.Swap(ref _board[first.Top + 8, first.Left], ref _board[second.Top + 8, second.Left]);
                failAnimCallback(first, second);
            }
        }

        private void DeleteMatches(Action<Cell> removeCell)
        {
            foreach (var match in _lastMatches)
            {
                removeCell(_board[match.Top + 8, match.Left]);
                _board[match.Top + 8, match.Left] = null;
            }
        }

        public void DeleteAndDropCells(Action<Cell> cellDropAnimation, Action<Cell> setCell, Action<Cell> removeCell)
        {
            DeleteMatches(removeCell);
            var dropLengths = new int[8];
            for (int i = 16 - 1; i >= 0; i--)
            {
                for (var j = 0; j < 8; j++)
                {
                    if (_board[i, j] == null)
                        dropLengths[j]++;
                    else if (dropLengths[j] != 0)
                    {
                        if (_board[i + dropLengths[j], j] != null)
                        {
                            throw new InvalidOperationException("It is not null where cell is dropped");
                        }

                        Utility.Swap(ref _board[i, j], ref _board[i + dropLengths[j], j]);
                        _board[i + dropLengths[j], j].Top = i + dropLengths[j] - 8;
                        cellDropAnimation(_board[i + dropLengths[j], j]);
                    }
                }
            }

            FillBoard(setCell);
        }

        private List<Cell> CheckMatches()
        {
            var delete = new bool[16, 8];
            for (var i = 8; i < 16; i++)
            {
                var matches = 1;
                var haveBonus = false;
                var haveBomb = false;
                int bombLocationX = 0;
                int bombLocationY = 0;
                var ptype = _board[i, 0].PieceType;
                for (var j = 1; j < 8; j++)
                {
                    if (_board[i, j].PieceType == ptype)
                    {
                        ++matches;
                        if (_board[i, j].IsBonus)
                            haveBonus = true;

                        if (_board[i, j].IsBomb)
                        {
                            bombLocationX = i;
                            bombLocationY = j;
                            haveBomb = true;
                        }
                    }
                    else
                    {
                        if (matches == 3)//simple case
                        {
                            if (haveBomb)
                            {
                                //bomb logic
                                if (bombLocationX - 1 > 7 && bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX - 1, bombLocationY - 1] = true;
                                }
                                if (bombLocationX - 1 > 7)
                                {
                                    delete[bombLocationX - 1, bombLocationY] = true;
                                }
                                if (bombLocationX - 1 > 7 && bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX - 1, bombLocationY + 1] = true;
                                }

                                if (bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX, bombLocationY - 1] = true;
                                }
                                if (bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX, bombLocationY + 1] = true;
                                }

                                if (bombLocationX + 1 < 16 && bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX + 1, bombLocationY - 1] = true;
                                }
                                if (bombLocationX + 1 < 16)
                                {
                                    delete[bombLocationX + 1, bombLocationY] = true;
                                }
                                if (bombLocationX + 1 < 16 && bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX + 1, bombLocationY + 1] = true;
                                }

                                delete[bombLocationX, bombLocationY] = true;
                            }
                            else if (haveBonus)
                            {
                                for (var k = 0; k < 8; k++)
                                {
                                    delete[i, k] = true;
                                }
                            }
                            else
                            {
                                for (var k = 1; k < matches + 1; k++)
                                {
                                    delete[i, j - k] = true;
                                }
                            }
                        }
                        else if (matches == 4)//line bonus
                        {
                            for (var k = 1; k < matches + 1; k++)
                            {
                                if (_topPoint == i - 8 && _leftPoint == j - k)
                                {
                                    delete[i, j - k] = false;
                                    _board[i, j - k].IsBonus = true;
                                }
                                else
                                {
                                    delete[i, j - k] = true;
                                }
                            }
                        }
                        else if (matches > 4)//bomb
                        {
                            for (var k = 1; k < matches + 1; k++)
                            {
                                if (_topPoint == i - 8 && _leftPoint == j - k)
                                {
                                    delete[i, j - k] = false;//cell for set bomb piece
                                    _board[i, j - k].IsBomb = true;
                                }
                                else
                                {
                                    delete[i, j - k] = true;
                                }
                            }
                        }

                        ptype = _board[i, j].PieceType;
                        matches = 1;
                    }
                }

                if (matches < 3) continue;
                for (var k = 1; k < matches + 1; k++)
                    delete[i, 8 - k] = true;
            }

            for (var i = 0; i < 8; i++)
            {
                var matches = 1;
                var haveBonus = false;
                var haveBomb = false;
                int bombLocationX = 0;
                int bombLocationY = 0;
                var ptype = _board[8, i].PieceType;
                for (var j = 9; j < 16; j++)
                {
                    if (_board[j, i].PieceType == ptype)
                    {
                        ++matches;
                        if (_board[j, i].IsBonus)
                            haveBonus = true;

                        if (_board[j, i].IsBomb)
                        {
                            bombLocationX = j;
                            bombLocationY = i;
                            haveBomb = true;
                        }
                    }
                    else
                    {
                        if (matches == 3)//simple case
                        {
                            if (haveBomb)
                            {
                                //bomb logic
                                if (bombLocationX - 1 > 8 && bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX - 1, bombLocationY - 1] = true;
                                }
                                if (bombLocationX - 1 > 8)
                                {
                                    delete[bombLocationX - 1, bombLocationY] = true;
                                }
                                if (bombLocationX - 1 > 8 && bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX - 1, bombLocationY + 1] = true;
                                }

                                if (bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX, bombLocationY - 1] = true;
                                }
                                if (bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX, bombLocationY + 1] = true;
                                }

                                if (bombLocationX + 1 < 16 && bombLocationY - 1 > 0)
                                {
                                    delete[bombLocationX + 1, bombLocationY - 1] = true;
                                }
                                if (bombLocationX + 1 < 16)
                                {
                                    delete[bombLocationX + 1, bombLocationY] = true;
                                }
                                if (bombLocationX + 1 < 16 && bombLocationY + 1 < 8)
                                {
                                    delete[bombLocationX + 1, bombLocationY + 1] = true;
                                }

                                delete[bombLocationX, bombLocationY] = true;
                            }
                            else if (haveBonus)
                            {
                                for (var k = 8; k < 16; k++)
                                    delete[k, i] = true;
                            }
                            else
                            {
                                for (var k = 1; k < matches + 1; k++)
                                    delete[j - k, i] = true;
                            }
                        }
                        if (matches == 4)//line bonus
                        {
                            for (var k = 1; k < matches + 1; k++)
                            {
                                if (_topPoint == j - k - 8 && _leftPoint == i)
                                {
                                    delete[j - k, i] = false;//cell for set bonus piece
                                    _board[j - k, i].IsBonus = true;
                                }
                                else
                                {
                                    delete[j - k, i] = true;
                                }
                            }
                        }
                        else if (matches > 4)
                        {
                            for (var k = 1; k < matches + 1; k++)
                            {
                                if (_topPoint == j - k - 8 && _leftPoint == i)
                                {
                                    delete[j - k, i] = false;//cell for set bomb piece
                                    _board[j - k, i].IsBomb = true;
                                }
                                else
                                {
                                    delete[j - k, i] = true;
                                }
                            }
                        }

                        ptype = _board[j, i].PieceType;
                        matches = 1;
                    }
                }

                if (matches < 3) continue;
                for (var k = 1; k < matches + 1; k++)
                    delete[16 - k, i] = true;
            }

            var result = new List<Cell>();
            for (var i = 8; i < 16; i++)
            {
                for (var j = 0; j < 8; j++)
                {
                    if (delete[i, j])
                    {
                        result.Add(_board[i, j]);
                    }
                }
            }

            return result;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
