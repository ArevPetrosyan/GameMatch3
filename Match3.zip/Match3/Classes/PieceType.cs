﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace Match3.Classes
{
    public enum PieceType
    {
        Hexagon,
        Triangle,
        Diamond,
        Circle,
        Star,
        Bomb
    }

    public static class UIImages
    {
        public static ImageSource[] Images
        {
            get
            {
                return new ImageSource[]{
                     new BitmapImage(new Uri(@"Images/Hexagon.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/Triangle.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/Diamond.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/Circle.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/Star.png", UriKind.RelativeOrAbsolute)),

                     new BitmapImage(new Uri(@"Images/HexagonBonus.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/TriangleBonus.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/DiamondBonus.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/CircleBonus.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/StarBonus.png", UriKind.RelativeOrAbsolute)),

                     new BitmapImage(new Uri(@"Images/HexagonBomb.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/TriangleBomb.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/DiamondBomb.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/CircleBomb.png", UriKind.RelativeOrAbsolute)),
                     new BitmapImage(new Uri(@"Images/StarBomb.png", UriKind.RelativeOrAbsolute))
                };
            }
        }
    }
}
