﻿using Match3.Classes;
using System.Windows;
using System.Windows.Controls;

namespace Match3
{
    /// <summary>
    /// Interaction logic for GameOver.xaml
    /// </summary>
    public partial class GameOver : UserControl
    {
        public int Points { get; }

        public GameOver(int points)
        {
            InitializeComponent();
            Points = points;
            DataContext = this;
        }

        private void OkButton_OnClick(object sender, RoutedEventArgs e)
        {
            PageNavigation.Switch(new MainMenu());
        }
    }
}
