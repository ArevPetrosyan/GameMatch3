﻿using Match3.Classes;
using System;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;

namespace Match3
{
    /// <summary>
    /// Interaction logic for GamePage.xaml
    /// </summary>
    public partial class GamePage : UserControl
    {
        private readonly Game _game;
        private int _dropAnimationRegister;
        private int _deleteAnimationRegister;
        private int _failAnimationRegister;
        private Cell _selected;
        private int _successAnimationRegister;
        private Cell _secondSelectedCell;

        public GamePage()
        {
            InitializeComponent();
            _game = new Game(SetCell, RemoveCell, DropAnimation);
            DataContext = _game;
        }

        private void SetCell(Cell cell)
        {
            cell.Image.Height = GameCanvas.Height / 8;
            cell.Image.Width = GameCanvas.Width / 8;
            cell.Image.RenderTransform = new ScaleTransform(1.0, 1.0, cell.Image.Height / 2, cell.Image.Width / 2);
            GameCanvas.Children.Add(cell.Image);
            Canvas.SetTop(cell.Image, cell.Top * cell.Image.Height);
            Canvas.SetLeft(cell.Image, cell.Left * cell.Image.Width);
        }

        private void DropAnimation(Cell cell)
        {
            _dropAnimationRegister++;
            var animTop = new DoubleAnimation
            {
                To = cell.Top * cell.Image.Height,
                Duration = TimeSpan.FromMilliseconds(200),
            };
            animTop.Completed += delegate
            {
                _dropAnimationRegister--;
                if (_dropAnimationRegister != 0) return;
                _game.FillBoard(SetCell);
                _game.RemoveMatches(DeleteAnimation);
            };
            cell.Image.BeginAnimation(Canvas.TopProperty, animTop);
        }

        private void StartSelectionAnimation(Cell cell)
        {
            var anim = new DoubleAnimation
            {
                From = 1.0,
                To = 0.8,
                Duration = TimeSpan.FromMilliseconds(300),
                RepeatBehavior = RepeatBehavior.Forever,
                AutoReverse = true,
            };
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }

        private void StopSelectionAnimation(Cell cell)
        {
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, null);
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, null);
        }

        private void DeleteAnimation(Cell cell)
        {
            _deleteAnimationRegister += 2;
            var anim = new DoubleAnimation
            {
                From = 1.0,
                To = 0.0,
                Duration = TimeSpan.FromMilliseconds(300),
            };
            anim.Completed += delegate
            {
                _deleteAnimationRegister--;
                if (_deleteAnimationRegister == 0)
                    _game.DeleteAndDropCells(DropAnimation, SetCell, RemoveCell);
            };
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, anim);
            cell.Image.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, anim);
        }

        private void OnSuccessAnimationComplete(object o, EventArgs e)
        {
            _successAnimationRegister--;
            if (_successAnimationRegister == 0)
                _game.RemoveMatches(DeleteAnimation);
        }

        private void SuccessAnimation(Cell first, Cell second)
        {
            _successAnimationRegister += 2;
            AnimateSwap(first, second, OnSuccessAnimationComplete);
        }

        private void AnimateSwap(Cell first, Cell second, Action<object, EventArgs> onCompleted)
        {
            var dt = Math.Sign(Math.Abs(first.Top - second.Top));
            var dl = Math.Sign(Math.Abs(first.Left - second.Left));
            var animFirst = new DoubleAnimation
            {
                Duration = TimeSpan.FromMilliseconds(200),
            };
            var animSecond = new DoubleAnimation
            {
                Duration = TimeSpan.FromMilliseconds(200),
            };
            animFirst.Completed += (o, ea) => onCompleted(o, ea);
            animSecond.Completed += (o, ea) => onCompleted(o, ea);
            if (dt == 1)
            {
                animSecond.To = second.Top * second.Image.Height;
                animFirst.To = first.Top * first.Image.Height;
                first.Image.BeginAnimation(Canvas.TopProperty, animFirst);
                second.Image.BeginAnimation(Canvas.TopProperty, animSecond);
            }
            else if (dl == 1)
            {
                animSecond.To = second.Left * second.Image.Width;
                animFirst.To = first.Left * first.Image.Width;
                first.Image.BeginAnimation(Canvas.LeftProperty, animFirst);
                second.Image.BeginAnimation(Canvas.LeftProperty, animSecond);
            }
            else
            {
                throw new InvalidOperationException("Moving diagonally");
            }
        }

        private void FailAnimation(Cell first, Cell second)
        {
            _failAnimationRegister += 2;
            first.SwapCoordinates(ref second);
            AnimateSwap(
                first, second, (o1, e1) =>
                {
                    _failAnimationRegister--;
                    if (_failAnimationRegister != 0) return;
                    first.SwapCoordinates(ref second);
                    _failAnimationRegister += 2;
                    AnimateSwap(first, second, (o2, e2) => { _failAnimationRegister--; });
                });
        }

        private void RemoveCell(Cell cell)
        {
            GameCanvas.Children.Remove(cell.Image);
        }

        private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_failAnimationRegister + _deleteAnimationRegister + _successAnimationRegister + _dropAnimationRegister > 0)
                return;

            if (!(e.OriginalSource is Image ts)) return;
            var t = (Cell)(ts.Tag);
            if (t.Selected)
            {
                t.Selected = false;
                StopSelectionAnimation(t);
                _selected = null;
            }
            else
            {
                if (_selected != null)
                {
                    var tempCell = _selected;
                    _selected.Selected = false;
                    StopSelectionAnimation(_selected);
                    _selected = null;
                    _secondSelectedCell = t;
                    _game.TrySwapCells(t, tempCell, SuccessAnimation, FailAnimation);
                }
                else
                {
                    t.Selected = true;
                    _selected = t;
                    StartSelectionAnimation(t);
                }
            }
        }
    }
}
