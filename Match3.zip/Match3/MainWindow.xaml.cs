﻿using MahApps.Metro.Controls;
using Match3.Classes;
using System.Windows.Controls;

namespace Match3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            PageNavigation.PageSwitcher = this;
            PageNavigation.Switch(new MainMenu());
        }

        public void Navigate(UserControl nextPage)
        {
            Content = nextPage;
        }
    }

}
